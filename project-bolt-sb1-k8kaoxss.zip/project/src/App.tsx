import React, { useState } from 'react';
import { 
  Brain, 
  Code, 
  GitBranch, 
  TestTube, 
  Rocket, 
  Shield, 
  Zap, 
  Users, 
  TrendingUp, 
  CheckCircle, 
  ArrowRight,
  Clock,
  Target,
  BarChart3,
  Lightbulb,
  Settings,
  FileText,
  Search,
  Bot
} from 'lucide-react';

function App() {
  const [activePhase, setActivePhase] = useState(0);

  const sdlcPhases = [
    {
      phase: "Planning & Analysis",
      icon: <Lightbulb className="w-8 h-8" />,
      aiEnhancements: [
        "Automated requirement analysis",
        "Predictive project timeline estimation",
        "Resource optimization algorithms",
        "Risk assessment with ML models"
      ],
      description: "AI analyzes historical data to predict project outcomes and optimize resource allocation."
    },
    {
      phase: "Design",
      icon: <Settings className="w-8 h-8" />,
      aiEnhancements: [
        "Automated UI/UX pattern suggestions",
        "Architecture optimization",
        "Design consistency validation",
        "Performance-driven design recommendations"
      ],
      description: "Machine learning suggests optimal design patterns based on user behavior data."
    },
    {
      phase: "Implementation",
      icon: <Code className="w-8 h-8" />,
      aiEnhancements: [
        "Intelligent code completion",
        "Real-time code quality analysis",
        "Automated refactoring suggestions",
        "Security vulnerability detection"
      ],
      description: "AI-powered coding assistants accelerate development while maintaining code quality."
    },
    {
      phase: "Testing",
      icon: <TestTube className="w-8 h-8" />,
      aiEnhancements: [
        "Automated test case generation",
        "Intelligent bug detection",
        "Performance bottleneck identification",
        "Regression test optimization"
      ],
      description: "ML algorithms identify testing patterns and generate comprehensive test suites."
    },
    {
      phase: "Deployment",
      icon: <Rocket className="w-8 h-8" />,
      aiEnhancements: [
        "Automated deployment pipelines",
        "Environment compatibility checks",
        "Rollback decision automation",
        "Performance monitoring alerts"
      ],
      description: "Intelligent deployment systems ensure smooth releases with minimal downtime."
    },
    {
      phase: "Maintenance",
      icon: <Shield className="w-8 h-8" />,
      aiEnhancements: [
        "Predictive maintenance scheduling",
        "Automated issue triage",
        "Performance optimization suggestions",
        "Security patch management"
      ],
      description: "AI predicts system failures and automates maintenance tasks proactively."
    }
  ];

  const benefits = [
    {
      icon: <Clock className="w-12 h-12 text-blue-500" />,
      title: "50% Faster Development",
      description: "AI-powered automation reduces development time significantly"
    },
    {
      icon: <Target className="w-12 h-12 text-green-500" />,
      title: "85% Fewer Bugs",
      description: "Intelligent testing and code analysis catch issues early"
    },
    {
      icon: <BarChart3 className="w-12 h-12 text-purple-500" />,
      title: "40% Cost Reduction",
      description: "Optimized resource allocation and automated processes cut costs"
    },
    {
      icon: <TrendingUp className="w-12 h-12 text-orange-500" />,
      title: "300% ROI Increase",
      description: "Higher quality software delivered faster generates better returns"
    }
  ];

  const tools = [
    {
      category: "AI Development",
      items: ["GitHub Copilot", "Tabnine", "DeepCode", "CodeT5"]
    },
    {
      category: "Testing & QA",
      items: ["Testim", "Applitools", "Mabl", "Functionize"]
    },
    {
      category: "DevOps & Deployment",
      items: ["Harness", "LaunchDarkly", "Dynatrace", "PagerDuty"]
    },
    {
      category: "Project Management",
      items: ["Jira Intelligence", "Monday.com AI", "Asana Intelligence", "Linear AI"]
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-2">
              <Brain className="w-8 h-8 text-blue-600" />
              <span className="text-xl font-bold text-gray-900">SmartSDLC</span>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="#features" className="text-gray-600 hover:text-blue-600 transition-colors">Features</a>
              <a href="#phases" className="text-gray-600 hover:text-blue-600 transition-colors">SDLC Phases</a>
              <a href="#tools" className="text-gray-600 hover:text-blue-600 transition-colors">Tools</a>
              <a href="#benefits" className="text-gray-600 hover:text-blue-600 transition-colors">Benefits</a>
            </nav>
            <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
              Get Started
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-50 via-white to-purple-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="bg-blue-100 p-4 rounded-full">
                <Bot className="w-16 h-16 text-blue-600" />
              </div>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              AI-Enhanced
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> SDLC</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Transform your software development lifecycle with artificial intelligence. 
              Accelerate delivery, improve quality, and reduce costs through intelligent automation.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center">
                Start Your AI Journey <ArrowRight className="ml-2 w-5 h-5" />
              </button>
              <button className="border border-gray-300 text-gray-700 px-8 py-3 rounded-lg hover:bg-gray-50 transition-colors">
                Watch Demo
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Why Choose AI-Enhanced SDLC?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Leverage cutting-edge AI technologies to revolutionize every aspect of your development process.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-8 rounded-xl hover:shadow-lg transition-shadow">
              <Zap className="w-12 h-12 text-blue-600 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Intelligent Automation</h3>
              <p className="text-gray-600">Automate repetitive tasks and focus on creative problem-solving with AI-driven workflows.</p>
            </div>
            
            <div className="bg-gradient-to-br from-green-50 to-green-100 p-8 rounded-xl hover:shadow-lg transition-shadow">
              <Search className="w-12 h-12 text-green-600 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Predictive Analytics</h3>
              <p className="text-gray-600">Anticipate issues before they occur with machine learning-powered insights and predictions.</p>
            </div>
            
            <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-8 rounded-xl hover:shadow-lg transition-shadow">
              <Users className="w-12 h-12 text-purple-600 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Enhanced Collaboration</h3>
              <p className="text-gray-600">AI facilitates better team communication and knowledge sharing across development cycles.</p>
            </div>
            
            <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-8 rounded-xl hover:shadow-lg transition-shadow">
              <Shield className="w-12 h-12 text-orange-600 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Security First</h3>
              <p className="text-gray-600">Built-in security scanning and vulnerability detection throughout the development process.</p>
            </div>
            
            <div className="bg-gradient-to-br from-teal-50 to-teal-100 p-8 rounded-xl hover:shadow-lg transition-shadow">
              <TrendingUp className="w-12 h-12 text-teal-600 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Performance Optimization</h3>
              <p className="text-gray-600">Continuous performance monitoring and optimization suggestions powered by AI algorithms.</p>
            </div>
            
            <div className="bg-gradient-to-br from-pink-50 to-pink-100 p-8 rounded-xl hover:shadow-lg transition-shadow">
              <GitBranch className="w-12 h-12 text-pink-600 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Smart Version Control</h3>
              <p className="text-gray-600">Intelligent merge conflict resolution and automated code review suggestions.</p>
            </div>
          </div>
        </div>
      </section>

      {/* SDLC Phases Section */}
      <section id="phases" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              AI-Enhanced SDLC Phases
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Discover how artificial intelligence transforms each phase of the software development lifecycle.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <div className="space-y-4">
              {sdlcPhases.map((phase, index) => (
                <div
                  key={index}
                  className={`p-6 rounded-xl cursor-pointer transition-all ${
                    activePhase === index
                      ? 'bg-blue-600 text-white shadow-lg'
                      : 'bg-white hover:shadow-md'
                  }`}
                  onClick={() => setActivePhase(index)}
                >
                  <div className="flex items-center space-x-4">
                    <div className={`p-3 rounded-lg ${
                      activePhase === index ? 'bg-blue-500' : 'bg-gray-100'
                    }`}>
                      {phase.icon}
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold">{phase.phase}</h3>
                      <p className={`text-sm ${
                        activePhase === index ? 'text-blue-100' : 'text-gray-500'
                      }`}>
                        Phase {index + 1} of 6
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-white p-8 rounded-xl shadow-lg">
              <div className="flex items-center space-x-4 mb-6">
                <div className="p-3 bg-blue-100 rounded-lg">
                  {sdlcPhases[activePhase].icon}
                </div>
                <h3 className="text-2xl font-bold text-gray-900">
                  {sdlcPhases[activePhase].phase}
                </h3>
              </div>
              
              <p className="text-gray-600 mb-6">
                {sdlcPhases[activePhase].description}
              </p>
              
              <h4 className="text-lg font-semibold text-gray-900 mb-4">AI Enhancements:</h4>
              <div className="space-y-3">
                {sdlcPhases[activePhase].aiEnhancements.map((enhancement, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                    <span className="text-gray-700">{enhancement}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tools & Technologies */}
      <section id="tools" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Integrated AI Tools & Technologies
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Seamlessly integrate with leading AI-powered development tools and platforms.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {tools.map((category, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-xl">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">{category.category}</h3>
                <div className="space-y-2">
                  {category.items.map((tool, toolIndex) => (
                    <div key={toolIndex} className="bg-white p-3 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                      <span className="text-gray-700">{tool}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="benefits" className="py-20 bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Measurable Results
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Organizations using AI-enhanced SDLC report significant improvements across key metrics.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="bg-white p-8 rounded-xl shadow-lg text-center hover:shadow-xl transition-shadow">
                <div className="flex justify-center mb-4">
                  {benefit.icon}
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-4">
            Ready to Transform Your Development Process?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Join thousands of development teams already leveraging AI to build better software faster.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors">
              Start Free Trial
            </button>
            <button className="border border-gray-600 text-gray-300 px-8 py-3 rounded-lg hover:bg-gray-800 transition-colors">
              Schedule Demo
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Brain className="w-8 h-8 text-blue-500" />
                <span className="text-xl font-bold">SmartSDLC</span>
              </div>
              <p className="text-gray-400">
                Revolutionizing software development with artificial intelligence.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Platform</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Integrations</a></li>
                <li><a href="#" className="hover:text-white transition-colors">API</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Security</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Resources</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Documentation</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Tutorials</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Case Studies</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">About</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Support</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 pt-8 mt-8 text-center">
            <p className="text-gray-400">
              © 2025 SmartSDLC. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;